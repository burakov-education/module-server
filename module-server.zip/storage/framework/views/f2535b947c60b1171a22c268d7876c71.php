<?php $__env->startSection('content'); ?>
    <section class="container">
        <article class="card my-3">
            <div class="card-title bg-secondary bg-gradient p-3 text-light d-flex justify-content-between">
                <h3><?php echo e($product->name); ?></h3>
                <a href="" title="Delete good" class="btn-danger py-1 px-2 justify-content-center text-decoration-none fs-4">☠</a>
            </div>
            <div class="card-body d-flex justify-content-between flex-wrap">
                <div class="card-img d-flex justify-content-evenly flex-wrap">
                    <?php $__currentLoopData = $product->image_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($imageUrl); ?>" class="card-img-good" alt="Название товара">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card-info">
                    <p class="card-text text-black-50"><span class="text-dark">About: </span><?php echo e($product->description); ?></p>
                    <p class="card-text text-danger d-flex justify-content-end"><?php echo e($product->price); ?> ₽</p>
                </div>
            </div>
        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\module-server\resources\views/products/show.blade.php ENDPATH**/ ?>