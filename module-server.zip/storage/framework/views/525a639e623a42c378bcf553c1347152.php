<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <h1 class="mb-4">Categories</h1>
        <a href="<?php echo e(route('categories.create')); ?>">Create category</a>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle fs-5">
                <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Count</th>
                    <th class="text-end">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->title); ?></td>
                        <td><?php echo e($category->description); ?></td>
                        <td><?php echo e($category->products()->count()); ?></td>
                        <td class="text-end">
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('products.index', $category)); ?>"  type="button" class="btn btn-lg btn-outline-primary no-reverse">
                                    <img src="<?php echo e(asset('assets/img/icons/eye.svg')); ?>" alt="eye" class="action-image">
                                </a>
                                <a href="<?php echo e(route('categories.edit', $category)); ?>"  type="button" class="btn btn-lg btn-outline-success no-reverse">
                                    <img src="<?php echo e(asset('assets/img/icons/pencil.svg')); ?>" alt="eye" class="action-image">
                                </a>
                                <?php if($category->products()->count() === 0): ?>
                                    <a href="<?php echo e(route('categories.destroy', $category)); ?>" type="button" class="btn btn-lg btn-outline-danger no-reverse">
                                        <img src="<?php echo e(asset('assets/img/icons/trash.svg')); ?>" alt="eye" class="action-image">
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\module-server\resources\views/categories/index.blade.php ENDPATH**/ ?>