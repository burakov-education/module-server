<?php $__env->startSection('content'); ?>
    <section class="container">
        <div class="d-flex flex-column justify-content-center form-container good">
            <div class="card shadow">
                <div class="card-body">
                    <h2 class="text-center mb-4 fs-1">Edit good</h2>

                    <form action="<?php echo e(route('products.update', $product)); ?>" method="post" id="addGood" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <?php echo $__env->make('products._form', [
                            'product' => $product,
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <button type="submit" class="btn btn-primary w-100 my-2 fs-2">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\module-server\resources\views/products/edit.blade.php ENDPATH**/ ?>